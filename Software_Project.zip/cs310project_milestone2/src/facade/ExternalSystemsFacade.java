package facade;


import gateway.FinanceSysGateway;
import gateway.PearlSysGateway;
import model.LibraryMember;
import service.BusinessException;

public class ExternalSystemsFacade {

    private final PearlSysGateway pearlGateway;
    private final FinanceSysGateway financeGateway;

    private static final double DEPOSIT_AMOUNT = 1500.0;

    public ExternalSystemsFacade(PearlSysGateway pearlGateway,
                                 FinanceSysGateway financeGateway) {
        this.pearlGateway = pearlGateway;
        this.financeGateway = financeGateway;
    }

    /**
     * Validates the applicant with PearlSys and performs the deposit in FinanceSys,
     * Throws BusinessException if any of the steps fail.
     */
    public void registerAndActivateMemberInExternalSystems(LibraryMember member)
            throws BusinessException {

        //  Validate applicant in PearlSys
        boolean valid = pearlGateway.verifyMember(
                member.getName(),
                member.getAddress()
                // add whatever PearlSys needs
        );
        if (!valid) {
            throw new BusinessException("Applicant is not valid in PearlSys.");
        }

        // Transfer deposit in FinanceSys
        boolean transferOk = financeGateway.transferDeposit(
                member.getFinanceAccount(),
                DEPOSIT_AMOUNT
        );
        if (!transferOk) {
            throw new BusinessException("FinanceSys deposit failed.");
        }

    }
}

