package controller;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.layout.BorderPane;

import java.io.IOException;

public class MainController {

    @FXML
    private BorderPane rootPane;   

    @FXML
    private void onRegister() {
        loadCenter("RegisterMemberView.fxml");
    }

    @FXML
    private void onReserve() {
        loadCenter("ReserveItemView.fxml");
    }

    private void loadCenter(String fxmlName) {
        try {
            Node view = FXMLLoader.load(getClass().getResource("/ui/" + fxmlName));
            rootPane.setCenter(view);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
