package controller;

import app.MainApp;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import model.LibraryMember;
import service.BusinessException;

public class RegisterMemberController {

    @FXML private TextField nameField;
    @FXML private TextField addressField;
    @FXML private TextField financeField;
    @FXML private TextArea resultArea;

    @FXML
    private void onRegister() {
        String name = nameField.getText().trim();
        String address = addressField.getText().trim();
        String finance = financeField.getText().trim();

        if (name.isEmpty() || address.isEmpty() || finance.isEmpty()) {
            showAlert(Alert.AlertType.ERROR, "Missing Data", "Please fill in all fields.");
            return;
        }

        if (MainApp.membershipService == null) {
            showAlert(Alert.AlertType.ERROR, "Internal Error",
                    "Membership service is not initialized.");
            return;
        }

        resultArea.clear();

        try {
            LibraryMember member = MainApp.membershipService
                    .registerNewMember(name, address, finance);

            resultArea.setStyle("-fx-text-fill: green;");
            resultArea.setText(
                    "Registration Successful!\n" +
                    "Membership ID: " + member.getMembershipId() + "\n" +
                    "Deposit 1500 QR transferred.\n" +
                    "Membership ACTIVE."
            );

            showAlert(Alert.AlertType.INFORMATION, "Member Registered",
                    "Membership ID: " + member.getMembershipId());

            nameField.clear();
            addressField.clear();
            financeField.clear();

        } catch (BusinessException ex) {
            resultArea.setStyle("-fx-text-fill: red;");
            resultArea.setText("Failed: " + ex.getMessage());
            showAlert(Alert.AlertType.ERROR, "Registration Failed", ex.getMessage());
        }
    }

    private void showAlert(Alert.AlertType type, String title, String content) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.showAndWait();
    }
}

//package controller;
//
//import app.MainApp;
//import javafx.fxml.FXML;
//import javafx.scene.control.*;
//import model.LibraryMember;
//import service.BusinessException;
//
//public class RegisterMemberController {
//
//    @FXML private TextField nameField;
//    @FXML private TextField addressField;
//    @FXML private TextField financeField;
//    @FXML private TextArea resultArea;
//
//    @FXML
//    private void onRegister() {
//        String name = nameField.getText().trim();
//        String address = addressField.getText().trim();
//        String finance = financeField.getText().trim();
//
//        if (name.isEmpty() || address.isEmpty() || finance.isEmpty()) {
//            showAlert(Alert.AlertType.ERROR, "Missing Data",
//                    "Please fill in all fields.");
//            return;
//        }
//
//        resultArea.clear();
//
//        try {
//            LibraryMember member = MainApp.membershipService
//                    .registerNewMember(name, address, finance);
//
//            resultArea.setStyle("-fx-text-fill: green;");
//            resultArea.setText(
//                    "Registration Successful!\n" +
//                    "Membership ID: " + member.getMembershipId() + "\n" +
//                    "Deposit 1500 QR transferred.\n" +
//                    "Membership ACTIVE."
//            );
//
//            showAlert(Alert.AlertType.INFORMATION, "Member Registered",
//                    "Membership ID: " + member.getMembershipId());
//
//            nameField.clear();
//            addressField.clear();
//            financeField.clear();
//
//        } catch (BusinessException ex) {
//            resultArea.setStyle("-fx-text-fill: red;");
//            resultArea.setText("Failed: " + ex.getMessage());
//            showAlert(Alert.AlertType.ERROR, "Registration Failed", ex.getMessage());
//        }
//    }
//
//    private void showAlert(Alert.AlertType type, String title, String content) {
//        Alert alert = new Alert(type);
//        alert.setTitle(title);
//        alert.setHeaderText(null);
//        alert.setContentText(content);
//        alert.showAndWait();
//    }
//}
