package controller;

import app.MainApp;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import model.Reservation;
import service.BusinessException;

public class ReserveItemController {

    @FXML private TextField memberField;
    @FXML private TextField callNoField;
    @FXML private TextArea resultArea;

    @FXML
    private void onReserve() {
        String memberId = memberField.getText().trim();
        String callNo = callNoField.getText().trim();

        if (memberId.isEmpty() || callNo.isEmpty()) {
            showAlert(Alert.AlertType.ERROR, "Missing Data",
                    "Please enter Membership ID and Item Call Number.");
            return;
        }

        resultArea.clear();

        try {
            Reservation res = MainApp.reservationService
                    .reserveItem(memberId, callNo);

            resultArea.setStyle("-fx-text-fill: green;");
            resultArea.setText(
                    "Reservation Successful!\n" +
                    "Reservation ID: " + res.getReservationId() + "\n" +
                    "Item: " + res.getCallNo() + "\n" +
                    "Member: " + res.getMembershipId() + "\n" +
                    "Created: " + res.getCreatedAt()
            );

            showAlert(Alert.AlertType.INFORMATION, "Reservation Created",
                    "Reservation ID: " + res.getReservationId());

            memberField.clear();
            callNoField.clear();

        } catch (BusinessException ex) {
            resultArea.setStyle("-fx-text-fill: red;");
            resultArea.setText("Failed: " + ex.getMessage());
            showAlert(Alert.AlertType.ERROR, "Reservation Failed", ex.getMessage());
        }
    }

    private void showAlert(Alert.AlertType type, String title, String content) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.showAndWait();
    }
}
