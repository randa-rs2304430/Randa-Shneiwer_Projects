package model;

import java.time.LocalDateTime;

public class Reservation {

    private String reservationId;
    private String membershipId;
    private String callNo;
    private LocalDateTime createdAt;

    public Reservation(String reservationId, String membershipId, String callNo) {
        this.reservationId = reservationId;
        this.membershipId = membershipId;
        this.callNo = callNo;
        this.createdAt = LocalDateTime.now();
    }

    public String getReservationId() {
        return reservationId;
    }

    public String getMembershipId() {
        return membershipId;
    }

    public String getCallNo() {
        return callNo;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    @Override
    public String toString() {
        return "Reservation{" +
                "reservationId='" + reservationId + '\'' +
                ", membershipId='" + membershipId + '\'' +
                ", callNo='" + callNo + '\'' +
                ", createdAt=" + createdAt +
                '}';
    }
}
