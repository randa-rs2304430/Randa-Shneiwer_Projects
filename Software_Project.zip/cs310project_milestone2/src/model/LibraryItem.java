package model;

public class LibraryItem {

    private String callNo;
    private String title;
    private int year;
    private LibraryItemType type;
    private boolean reserved;

    public LibraryItem(String callNo, String title, int year, LibraryItemType type) {
        this.callNo = callNo;
        this.title = title;
        this.year = year;
        this.type = type;
        this.reserved = false;
    }

    public String getCallNo() {
        return callNo;
    }

    public String getTitle() {
        return title;
    }

    public int getYear() {
        return year;
    }

    public LibraryItemType getType() {
        return type;
    }

    public boolean isReserved() {
        return reserved;
    }

    public void setReserved(boolean reserved) {
        this.reserved = reserved;
    }

    @Override
    public String toString() {
        return "LibraryItem{" +
                "callNo='" + callNo + '\'' +
                ", title='" + title + '\'' +
                ", year=" + year +
                ", type=" + type +
                ", reserved=" + reserved +
                '}';
    }
}
