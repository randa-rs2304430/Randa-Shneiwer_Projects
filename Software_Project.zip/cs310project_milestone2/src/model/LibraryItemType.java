package model;

public enum LibraryItemType {
    BOOK,
    DIGITAL_MEDIA,
    MAGAZINE
}
