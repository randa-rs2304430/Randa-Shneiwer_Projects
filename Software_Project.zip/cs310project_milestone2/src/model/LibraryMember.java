package model;

public class LibraryMember {

    private String membershipId;
    private String name;
    private String address;
    private String financeAccount;
    private int reservedCount;
    private boolean active;

    public LibraryMember(String membershipId, String name, String address, String financeAccount) {
        this.membershipId = membershipId;
        this.name = name;
        this.address = address;
        this.financeAccount = financeAccount;
        this.reservedCount = 0;
        this.active = true;
    }

    public String getMembershipId() {
        return membershipId;
    }

    public void setMembershipId(String membershipId) {
        this.membershipId = membershipId;
    }

    public String getName() {
        return name;
    }

    public String getAddress() {
        return address;
    }

    public String getFinanceAccount() {
        return financeAccount;
    }

    public int getReservedCount() {
        return reservedCount;
    }

    public void setReservedCount(int reservedCount) {
        this.reservedCount = reservedCount;
    }

    public boolean isActive() {
        return active;
    }

    public void setActive(boolean active) {
        this.active = active;
    }

    @Override
    public String toString() {
        return "LibraryMember{" +
                "membershipId='" + membershipId + '\'' +
                ", name='" + name + '\'' +
                ", reservedCount=" + reservedCount +
                ", active=" + active +
                '}';
    }
}
