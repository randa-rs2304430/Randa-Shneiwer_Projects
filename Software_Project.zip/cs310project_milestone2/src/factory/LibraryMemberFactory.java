package factory;

import model.LibraryMember;

public class LibraryMemberFactory {

    private int nextId = 1000;  

    public LibraryMember createMember(String name, String address, String financeAccNo) {
        // Generate unique membership ID 
        String membershipId = "M" + nextId++;
        
       
        LibraryMember member = new LibraryMember(
                membershipId,
                name,
                address,
                financeAccNo
        );

        return member;
    }
}
