package service;

import model.LibraryItem;
import model.LibraryMember;
import model.Reservation;
import repo.ItemRepository;
import repo.MemberRepository;
import repo.ReservationRepository;

public class ReservationService {

    private final MemberRepository memberRepository;
    private final ItemRepository itemRepository;
    private final ReservationRepository reservationRepository;

    private static final int MAX_RESERVATIONS_PER_MEMBER = 3;

    public ReservationService(MemberRepository memberRepository,
                              ItemRepository itemRepository,
                              ReservationRepository reservationRepository) {
        this.memberRepository = memberRepository;
        this.itemRepository = itemRepository;
        this.reservationRepository = reservationRepository;
    }

    // "Reserve item" use case (normal scenario).
  
    public Reservation reserveItem(String membershipId,
                                   String callNo) throws BusinessException {

        if (membershipId == null || membershipId.isBlank()
                || callNo == null || callNo.isBlank()) {
            throw new BusinessException("Membership ID and Item call number are required.");
        }

        //Find and validate member
        LibraryMember member = memberRepository.findById(membershipId);
        if (member == null || !member.isActive()) {
            throw new BusinessException("Invalid or inactive member.");
        }

        //Check reservation limit
        int currentReservations = reservationRepository.countReservationsByMember(membershipId);
        if (currentReservations >= MAX_RESERVATIONS_PER_MEMBER) {
            throw new BusinessException("Reservation limit reached (" + MAX_RESERVATIONS_PER_MEMBER + ").");
        }

        //Find item
        LibraryItem item = itemRepository.findByCallNo(callNo);
        if (item == null) {
            throw new BusinessException("Item not found for call number: " + callNo);
        }

        //Check if already reserved
        if (item.isReserved()) {
            throw new BusinessException("Item is already reserved by another member.");
        }

        // Create reservation
        String reservationId = generateReservationId();
        Reservation reservation = new Reservation(reservationId, membershipId, callNo);
        reservationRepository.save(reservation);

        // Update item & member
        item.setReserved(true);
        itemRepository.save(item);

        member.setReservedCount(currentReservations + 1);
        memberRepository.save(member);

        return reservation;
    }

    private String generateReservationId() {
        return "R" + System.currentTimeMillis();
    }
}
