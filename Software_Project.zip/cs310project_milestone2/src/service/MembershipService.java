package service;

import facade.ExternalSystemsFacade;
import factory.LibraryMemberFactory;
import model.LibraryMember;
import repo.MemberRepository;

public class MembershipService {

    private final MemberRepository memberRepository;
    private final LibraryMemberFactory memberFactory;
	private ExternalSystemsFacade externalSystems;


    public MembershipService(MemberRepository memberRepository,
            LibraryMemberFactory memberFactory,
            ExternalSystemsFacade externalSystems) {
this.memberRepository = memberRepository;
this.memberFactory = memberFactory;
this.externalSystems = externalSystems;
}


    // "Register new member" use case 
     
    public LibraryMember registerNewMember(String name,
                                           String address,
                                           String financeAccount) throws BusinessException {

        if (name == null || name.isBlank()
                || address == null || address.isBlank()
                || financeAccount == null || financeAccount.isBlank()) {
            throw new BusinessException("All fields are required.");
        }
        
        //1) Check duplicate member
        boolean exists = (memberRepository.findByFinanceAccount(financeAccount)) != null;
        if (exists) {
        	throw new BusinessException("Applicant is already a member");
        }

  
//        boolean verified = pearlSysGateway.verifyMember(name, financeAccount);
//        if (!verified) {
//            throw new BusinessException("Applicant is not a valid university member (PearlSys verification failed).");
//        }
//
//        boolean transferred = financeSysGateway.transferDeposit(financeAccount, DEPOSIT_AMOUNT);
//        if (!transferred) {
//            throw new BusinessException("Deposit transfer failed. Please check FinanceSys account.");
//        }

        // Create the member using the Factory
        LibraryMember member = memberFactory.createMember(name, address, financeAccount);

        // Use the Façade to talk to external systems
        externalSystems.registerAndActivateMemberInExternalSystems(member);

        // If all external operations succeed, save the member internally
        memberRepository.save(member);
    

        return member;
    }

//    private String generateMembershipId() {
//        return "M" + System.currentTimeMillis();
//    }
}
