package test;

import model.LibraryItem;
import model.LibraryItemType;
import model.LibraryMember;
import org.junit.Before;
import org.junit.Test;
import repo.ItemRepository;
import repo.MemberRepository;
import repo.ReservationRepository;
import service.BusinessException;
import service.ReservationService;

import static org.junit.Assert.*;

public class ReservationServiceTest {

    private MemberRepository memberRepo;
    private ItemRepository itemRepo;
    private ReservationRepository reservationRepo;
    private ReservationService reservationService;

    private LibraryMember member;
    private LibraryItem item;

    @Before
    public void setUp() {
        memberRepo = new MemberRepository();
        itemRepo = new ItemRepository();
        reservationRepo = new ReservationRepository();
        reservationService = new ReservationService(memberRepo, itemRepo, reservationRepo);

        // Seed one member + one item
        member = new LibraryMember("M1001", "A Member", "Doha", "ACC1001");
        memberRepo.save(member);

        item = new LibraryItem("B001", "Software Engineering", 2020, LibraryItemType.BOOK);
        itemRepo.save(item);
    }

    @Test
    public void testReserveItem_success() throws BusinessException {
        reservationService.reserveItem(member.getMembershipId(), item.getCallNo());

        // verify
        assertTrue("Item should be marked as reserved",
                reservationRepo.isReserved(item.getCallNo()));
    }

    @Test(expected = BusinessException.class)
    public void testReserveItem_memberDoesNotExist_shouldThrow() throws BusinessException {
        reservationService.reserveItem("M9999", "B001");
    }

    @Test(expected = BusinessException.class)
    public void testReserveItem_itemDoesNotExist_shouldThrow() throws BusinessException {
        reservationService.reserveItem(member.getMembershipId(), "X999");
    }

    @Test(expected = BusinessException.class)
    public void testReserveItem_itemAlreadyReserved_shouldThrow() throws BusinessException {
        // First reservation OK
        reservationService.reserveItem(member.getMembershipId(), item.getCallNo());

        // Second reservation for same item by another member → should fail
        LibraryMember other =
                new LibraryMember("M2002", "Other Member", "Doha", "ACC2002");
        memberRepo.save(other);

        reservationService.reserveItem(other.getMembershipId(), item.getCallNo());
    }

    @Test(expected = BusinessException.class)
    public void testReserveItem_memberAtReservationLimit_shouldThrow() throws BusinessException {
        int limit = 3; 
        // Reserve up to limit
        for (int i = 0; i < limit; i++) {
            LibraryItem extra = new LibraryItem("B10" + i, "Book " + i, 2020, LibraryItemType.BOOK);
            itemRepo.save(extra);
            reservationService.reserveItem(member.getMembershipId(), extra.getCallNo());
        }

        // One more item beyond the limit
        LibraryItem beyondLimit =
                new LibraryItem("B999", "Over Limit", 2020, LibraryItemType.BOOK);
        itemRepo.save(beyondLimit);

      
        reservationService.reserveItem(member.getMembershipId(), beyondLimit.getCallNo());
    }
}
