package test;

import model.LibraryItem;
import model.LibraryItemType;
import model.LibraryMember;
import org.apache.jmeter.config.Arguments;
import org.apache.jmeter.protocol.java.sampler.JavaSamplerClient;
import org.apache.jmeter.protocol.java.sampler.JavaSamplerContext;
import org.apache.jmeter.samplers.SampleResult;
import repo.ItemRepository;
import repo.MemberRepository;
import repo.ReservationRepository;
import service.BusinessException;
import service.ReservationService;

public class ReserveReliabilityTest implements JavaSamplerClient {

    @Override
    public void setupTest(JavaSamplerContext context) {
        // Nothing global needed here; we'll create fresh repos per run
    
    }

    @Override
    public SampleResult runTest(JavaSamplerContext context) {
        SampleResult result = new SampleResult();
        result.sampleStart();  // start timing

        try {
            // Fresh in-memory repos for this test execution
            MemberRepository memberRepo = new MemberRepository();
            ItemRepository itemRepo = new ItemRepository();
            ReservationRepository reservationRepo = new ReservationRepository();
            ReservationService reservationService =
                    new ReservationService(memberRepo, itemRepo, reservationRepo);

         
            LibraryMember member1 =
                    new LibraryMember("M1001", "A Member", "Doha", "ACC1001");
            memberRepo.save(member1);

            LibraryMember member2 =
                    new LibraryMember("M2002", "A2 Member", "Doha", "ACC2002");
            memberRepo.save(member2);

            LibraryItem item =
                    new LibraryItem("B001", "Software Engineering", 2020, LibraryItemType.BOOK);
            itemRepo.save(item);

            // 1) First reservation → should succeed
            reservationService.reserveItem(member1.getMembershipId(), item.getCallNo());

            // 2) Second reservation on same item by another member → should FAIL
            try {
                reservationService.reserveItem(member2.getMembershipId(), item.getCallNo());
                // If no exception, reliability test actually FAILED
                result.setSuccessful(false);
                result.setResponseMessage("Expected BusinessException for already reserved item, but none thrown.");
                result.setResponseCode("500");
            } catch (BusinessException expected) {
                // This is the behavior we want: controlled failure, no crash
                result.setSuccessful(true);
                result.setResponseMessage("Reliability OK: second reservation correctly rejected: " + expected.getMessage());
                result.setResponseCodeOK();
            }

        } catch (Exception e) {
            result.setSuccessful(false);
            result.setResponseMessage("Unexpected error: " + e.toString());
            result.setResponseCode("500");
        } finally {
            result.sampleEnd();
        }

        return result;
    }

    @Override
    public void teardownTest(JavaSamplerContext context) {
    }

    @Override
    public Arguments getDefaultParameters() {
        return new Arguments();  
    }
}

