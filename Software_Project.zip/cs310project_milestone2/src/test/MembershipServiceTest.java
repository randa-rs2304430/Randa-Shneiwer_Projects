package test;

import gateway.FinanceSysGateway;
import gateway.FinanceSysGatewayMock;
import gateway.PearlSysGateway;
import gateway.PearlSysGatewayMock;
import model.LibraryMember;
import org.junit.Before;
import org.junit.Test;

import facade.ExternalSystemsFacade;
import factory.LibraryMemberFactory;
import repo.MemberRepository;
import service.BusinessException;
import service.MembershipService;

import static org.junit.Assert.*;

public class MembershipServiceTest {

    private MemberRepository memberRepo;
    private MembershipService membershipService;

    @Before
    public void setUp() {
    	memberRepo = new MemberRepository();
    	PearlSysGateway pearl = new PearlSysGatewayMock();
    	FinanceSysGateway finance = new FinanceSysGatewayMock();
    	LibraryMemberFactory memberFactory = new LibraryMemberFactory();
    	ExternalSystemsFacade externalFacade =
    	        new ExternalSystemsFacade(pearl, finance);

    	membershipService = new MembershipService(memberRepo, memberFactory, externalFacade);

    }

    @Test
    public void testRegisterNewMember_success() throws BusinessException {
      
        String name = "Aisha";
        String address = "Doha";
        String financeAccNo = "ADD432";

     
        LibraryMember member =
                membershipService.registerNewMember(name, address, financeAccNo);

   
        assertNotNull("Member should not be null", member);
        assertNotNull("Membership ID should be generated", member.getMembershipId());
        assertEquals("Name must match", name, member.getName());
        assertEquals("Address must match", address, member.getAddress());

        // verify actually stored
        LibraryMember fromRepo =
                memberRepo.findById(member.getMembershipId());
        assertNotNull("Member should be stored in repository", fromRepo);
    }

    @Test (expected = BusinessException.class) 
    // If no exception, test fails automatically because of expected=...
    public void testRegisterNewMember_missingFinanceAccount_shouldThrow() throws BusinessException {
        String name = "Alma";
        String address = "Doha";
        String financeAccNo = "";

        membershipService.registerNewMember(name, address, financeAccNo);
    }

    @Test (expected = BusinessException.class)
    public void testRegisterNewMember_invalidName_shouldThrow() throws BusinessException {
        String name = "Test User";  
        // Make PearlSysGatewayMock fail for this name doesn't start with A
        String address = "Doha";
        String badAccount = "BADACC"; 

        membershipService.registerNewMember(name, address, badAccount);
    }

    @Test (expected = BusinessException.class)
    public void testRegisterNewMember_duplicateFinanceAccount_shouldThrow() throws BusinessException {
        String name1 = "A User";
        String name2 = "A2 User";
        String address = "Doha";
        String account = "FHH3245";

        // First registration OK
        membershipService.registerNewMember(name1, address, account);

        // Second registration with same account should throw
        membershipService.registerNewMember(name2, address, account);
    }
}
