package test;

import gateway.FinanceSysGateway;
import gateway.FinanceSysGatewayMock;
import gateway.PearlSysGateway;
import gateway.PearlSysGatewayMock;
import model.LibraryMember;
import org.apache.jmeter.config.Arguments;
import org.apache.jmeter.protocol.java.sampler.JavaSamplerClient;
import org.apache.jmeter.protocol.java.sampler.JavaSamplerContext;
import org.apache.jmeter.samplers.SampleResult;

import facade.ExternalSystemsFacade;
import factory.LibraryMemberFactory;
import repo.MemberRepository;
import service.BusinessException;
import service.MembershipService;

public class RegisterPerformanceTest implements JavaSamplerClient {

    // These will be created once per test setup
    private MemberRepository memberRepo;
    private MembershipService membershipService;

    @Override
    public void setupTest(JavaSamplerContext context) {
    	memberRepo = new MemberRepository();
    	PearlSysGateway pearl = new PearlSysGatewayMock();
    	FinanceSysGateway finance = new FinanceSysGatewayMock();
    	LibraryMemberFactory memberFactory = new LibraryMemberFactory();
    	ExternalSystemsFacade externalFacade =
    	        new ExternalSystemsFacade(pearl, finance);

    	membershipService = new MembershipService(memberRepo, memberFactory, externalFacade);
  }

    @Override
    public SampleResult runTest(JavaSamplerContext context) {
        SampleResult result = new SampleResult();
        result.sampleStart();  // start timing

        try {
            // Read optional parameters from JMeter (with defaults)
            String baseName = context.getParameter("baseName");
            String addressPrefix = context.getParameter("addressPrefix");

            if (baseName == null || baseName.isEmpty()) {
                baseName = "PerfUser";
            }
            if (addressPrefix == null || addressPrefix.isEmpty()) {
                addressPrefix = "Doha";
            }

            // Generate unique data per invocation
            long threadId = Thread.currentThread().getId();
            String name = "A" + baseName + "-" + threadId + "-" + System.nanoTime();
            String address = addressPrefix + " - Street 1";
            String financeAccNo = "ACC-" + System.nanoTime();

            // Call the service under test
            LibraryMember member =
                    membershipService.registerNewMember(name, address, financeAccNo);

            // If we got here with no exceptions, success
            if (member == null || member.getMembershipId() == null) {
                // Treat this as a failure
                result.setSuccessful(false);
                result.setResponseMessage("Member or membershipId is null");
                result.setResponseCode("500");
            } else {
                result.setSuccessful(true);
                result.setResponseMessage("Registration executed successfully");
                result.setResponseCodeOK();
            }

        } catch (BusinessException e) {
            // Business-level failure (e.g., validation) – count as failure here
            result.setSuccessful(false);
            result.setResponseMessage("Business error: " + e.getMessage());
            result.setResponseCode("400");
        } catch (Exception e) {
            // Unexpected technical errors
            result.setSuccessful(false);
            result.setResponseMessage("Unexpected error: " + e.toString());
            result.setResponseCode("500");
        } finally {
            result.sampleEnd();  // end timing
        }

        return result;
    }

    @Override
    public void teardownTest(JavaSamplerContext context) {
        // cleanup
        memberRepo = null;
        membershipService = null;
    }

    @Override
    public Arguments getDefaultParameters() {
        Arguments args = new Arguments();
        args.addArgument("baseName", "PerfUser");
        args.addArgument("addressPrefix", "Doha");
        return args;
    }
}
