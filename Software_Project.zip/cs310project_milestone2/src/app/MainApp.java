package app;

import facade.ExternalSystemsFacade;
import factory.LibraryMemberFactory;
import gateway.FinanceSysGateway;
import gateway.FinanceSysGatewayMock;
import gateway.PearlSysGateway;
import gateway.PearlSysGatewayMock;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;
import model.LibraryItem;
import model.LibraryItemType;
import model.LibraryMember;
import repo.ItemRepository;
import repo.MemberRepository;
import repo.ReservationRepository;
import service.MembershipService;
import service.ReservationService;

public class MainApp extends Application {

    public static MemberRepository memberRepository = new MemberRepository();
    public static ItemRepository itemRepository = new ItemRepository();
    public static ReservationRepository reservationRepository = new ReservationRepository();

    public static MembershipService membershipService;
    public static ReservationService reservationService;

    @Override
    public void start(Stage stage) throws Exception {
        System.out.println("MainApp.start() called");

        // 1) Seed items (for testing)
        itemRepository.save(new LibraryItem("B001", "Software Engineering", 2020, LibraryItemType.BOOK));
        itemRepository.save(new LibraryItem("B002", "Data Structures", 2019, LibraryItemType.BOOK));

        // 2) Optional test member
        LibraryMember m = new LibraryMember("MTEST1", "A Member", "Doha", "ACC999");
        memberRepository.save(m);

        // 3) Create external access
        PearlSysGateway pearl = new PearlSysGatewayMock();
        FinanceSysGateway finance = new FinanceSysGatewayMock();
        ExternalSystemsFacade externalFacade =
                new ExternalSystemsFacade(pearl, finance);

        // 4) Initialize services 
        LibraryMemberFactory memberFactory = new LibraryMemberFactory();
        membershipService = new MembershipService(memberRepository, memberFactory, externalFacade);
        reservationService = new ReservationService(memberRepository, itemRepository, reservationRepository);

        // 5) Load main UI
        var url = getClass().getResource("/ui/MainView.fxml");
        System.out.println("Loaded FXML URL = " + url);

        FXMLLoader loader = new FXMLLoader(url);
        Scene scene = new Scene(loader.load(), 800, 400);
        stage.setScene(scene);
        stage.setTitle("Gulf Pearl University Library System");
        stage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}


//package app;
//
//import gateway.*;
//import model.*;
//import repo.*;
//import service.*;
//import javafx.application.Application;
//import javafx.fxml.FXMLLoader;
//import javafx.scene.Scene;
//import javafx.stage.Stage;
//
//public class MainApp extends Application {
//
//    public static MemberRepository memberRepository = new MemberRepository();
//    public static ItemRepository itemRepository = new ItemRepository();
//    public static ReservationRepository reservationRepository = new ReservationRepository();
//
//    public static MembershipService membershipService;
//    public static ReservationService reservationService;
//
//    @Override
//    public void start(Stage stage) throws Exception {
//        System.out.println("MainApp.start() called");
//
//        var url = getClass().getResource("/ui/MainView.fxml");
//        System.out.println("Loaded FXML URL = " + url);
//
//        FXMLLoader loader = new FXMLLoader(url);
//        Scene scene = new Scene(loader.load());
//        stage.setScene(scene);
//        stage.setTitle("Gulf Pearl University Library System");
//        stage.show();
//    }
//
//
//    public static void main(String[] args) {
//        launch();
//    }
//}