package gateway;

public interface PearlSysGateway {

    boolean verifyMember(String name, String financeAccount);
}
