package gateway;

public class FinanceSysGatewayMock implements FinanceSysGateway {

    @Override
    public boolean transferDeposit(String financeAccount, double amount) {
        // For demo: valid if non-empty and amount is exactly 1500
        return financeAccount != null && !financeAccount.isEmpty() && amount == 1500.0;
    }
}
