package gateway;

public interface FinanceSysGateway {

    boolean transferDeposit(String financeAccount, double amount);
}
