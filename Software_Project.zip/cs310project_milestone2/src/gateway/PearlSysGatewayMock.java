package gateway;


public class PearlSysGatewayMock implements PearlSysGateway {

    @Override
    public boolean verifyMember(String name, String financeAccount) {
        // Simple rule for demo: valid if finance account is not empty and name starts with "A"
        return !financeAccount.isEmpty()&& name.startsWith("A");
    }
}

