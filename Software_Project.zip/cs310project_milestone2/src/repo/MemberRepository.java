package repo;

import model.LibraryMember;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

public class MemberRepository {

    private final Map<String, LibraryMember> members = new HashMap<>();

    public LibraryMember findById(String membershipId) {
        return members.get(membershipId);
    }

    public void save(LibraryMember member) {
        members.put(member.getMembershipId(), member);
    }

    public Collection<LibraryMember> findAll() {
        return members.values();
    }
    
    public LibraryMember findByFinanceAccount(String financeAccount) {

        for (LibraryMember m : members.values()) {
            if (financeAccount.equals(m.getFinanceAccount())) {
                return m;
            }
        }
        return null;
    }

}