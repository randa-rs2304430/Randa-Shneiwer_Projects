package repo;

import model.Reservation;

import java.util.ArrayList;
import java.util.List;

public class ReservationRepository {

    private final List<Reservation> reservations = new ArrayList<>();

    public void save(Reservation reservation) {
        reservations.add(reservation);
    }

    public int countReservationsByMember(String membershipId) {
        int count = 0;
        for (Reservation r : reservations) {
            if (r.getMembershipId().equals(membershipId)) {
                count++;
            }
        }
        return count;
    }

    public List<Reservation> findAll() {
        return reservations;
    }

	public boolean isReserved(String callNo) {
		boolean found=false;
		for (Reservation r : reservations) {
            if (r.getCallNo().equals(callNo)) {
            	found=true;
            	break;
            }
        }
		return found;
	}
}