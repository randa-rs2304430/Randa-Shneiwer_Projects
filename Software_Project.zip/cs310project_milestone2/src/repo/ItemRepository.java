package repo;

import model.LibraryItem;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

public class ItemRepository {

    private final Map<String, LibraryItem> items = new HashMap<>();

    public LibraryItem findByCallNo(String callNo) {
        return items.get(callNo);
    }

    public void save(LibraryItem item) {
        items.put(item.getCallNo(), item);
    }

    public Collection<LibraryItem> findAll() {
        return items.values();
    }
}
