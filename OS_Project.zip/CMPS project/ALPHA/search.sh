#!/bin/bash

# Search the home directory for files larger than 1 MB.

set -u

REPORT="$HOME/CMPS405/bigfile"
TEMP_LIST=$(mktemp)

# Make sure the output directory exists.
mkdir -p "$HOME/CMPS405"

# Search for regular files larger than 1 MB.
find "$HOME" -type f -size +1M -print 2>/dev/null | sort > "$TEMP_LIST"

# Count the files found.
COUNT=$(wc -l < "$TEMP_LIST")

# Save the date, count, and search results.
{
    echo "File Search Report"
    echo "Search date: $(date '+%Y-%m-%d %H:%M:%S')"
    echo "Files larger than 1 MB: $COUNT"
    echo
    echo "Matching files:"
    if [ "$COUNT" -gt 0 ]; then
        cat "$TEMP_LIST"
    else
        echo "No files larger than 1 MB were found."
    fi
} > "$REPORT"

# Display the report on the terminal.
cat "$REPORT"

# Send an email only when matching files are found.
if [ "$COUNT" -gt 0 ]; then
    if ! command -v mail >/dev/null 2>&1; then
        echo "ERROR: The mail command is not installed."
        echo "Install and configure a mail client before sending email."
        rm -f "$TEMP_LIST"
        exit 1
    fi

    read -r -p "Enter your personal email address: " ADMIN_EMAIL

    if [ -z "$ADMIN_EMAIL" ]; then
        echo "ERROR: Email address cannot be empty."
        rm -f "$TEMP_LIST"
        exit 1
    fi

    if mail -s "ALPHA: Large File Search Report" \
        "$ADMIN_EMAIL" < "$REPORT"; then
        echo "Email submitted to the configured mail system."
    else
        echo "ERROR: Email submission failed."
        rm -f "$TEMP_LIST"
        exit 1
    fi
else
    echo "No matching files found. No email was sent."
fi

rm -f "$TEMP_LIST"
