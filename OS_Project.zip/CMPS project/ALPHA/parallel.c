
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <dirent.h>
#include <time.h>
#include <errno.h>
#include <limits.h>
#include <sys/file.h>

#define TASK_COUNT 6

void write_log(const char *logfile, const char *message)
{
    int fd = open(logfile, O_WRONLY | O_APPEND | O_CREAT, 0644);
    if (fd < 0) {
        perror("Opening log file");
        return;
    }

    flock(fd, LOCK_EX);
    dprintf(fd, "%s\n", message);
    flock(fd, LOCK_UN);
    close(fd);
}

int copy_file(const char *source, const char *destination)
{
    int in = open(source, O_RDONLY);
    if (in < 0) return -1;

    int out = open(destination, O_WRONLY | O_CREAT | O_TRUNC, 0644);
    if (out < 0) {
        close(in);
        return -1;
    }

    char buffer[4096];
    ssize_t bytes;
    int result = 0;

    while ((bytes = read(in, buffer, sizeof(buffer))) > 0) {
        ssize_t written = 0;
        while (written < bytes) {
            ssize_t n = write(out, buffer + written, bytes - written);
            if (n < 0) {
                result = -1;
                break;
            }
            written += n;
        }
        if (result < 0) break;
    }

    if (bytes < 0) result = -1;

    close(in);
    close(out);
    return result;
}

void perform_task(int task, int child_number,
                  const char *directory, const char *source,
                  const char *word, const char *logfile)
{
    char path[PATH_MAX];
    char details[512];
    char timestamp[80];
    char message[1024];
    int success = 0;

    time_t now = time(NULL);
    struct tm local_time;
    localtime_r(&now, &local_time);
    strftime(timestamp, sizeof(timestamp),
             "%Y-%m-%d %H:%M:%S", &local_time);

    switch (task) {

    case 0: /* Create a file */
        snprintf(path, sizeof(path), "%s/created_%d.txt",
                 directory, child_number);

        {
            int fd = open(path, O_WRONLY | O_CREAT | O_EXCL, 0644);
            if (fd >= 0) {
                dprintf(fd, "Created by child process %d\n",
                        child_number);
                close(fd);
                snprintf(details, sizeof(details),
                         "Created file %.200s", path);
                success = 1;
            }
        }
        break;

    case 1: /* Delete a file */
        snprintf(path, sizeof(path), "%s/delete_target_%d.txt",
                 directory, child_number);

        if (unlink(path) == 0) {
            snprintf(details, sizeof(details),
                     "Deleted file %.200s", path);
            success = 1;
        }
        break;

    case 2: /* Copy a file */
        snprintf(path, sizeof(path), "%s/copy_%d.txt",
                 directory, child_number);

        if (copy_file(source, path) == 0) {
            snprintf(details, sizeof(details),
                     "Copied %.200s to %.200s", source, path);
            success = 1;
        }
        break;

    case 3: /* Display file information */
        {
            struct stat info;

            if (stat(source, &info) == 0) {
                snprintf(details, sizeof(details),
                         "File: %s | Size: %lld bytes | Permissions: %o",
                         source, (long long)info.st_size,
                         info.st_mode & 0777);
                success = 1;
            }
        }
        break;

    case 4: /* Search for a word */
        {
            FILE *file = fopen(source, "r");

            if (file != NULL) {
                char *line = NULL;
                size_t length = 0;
                ssize_t read_length;
                int matches = 0;

                while ((read_length =
                        getline(&line, &length, file)) != -1) {
                    if (strstr(line, word) != NULL)
                        matches++;
                }

                free(line);
                fclose(file);

                snprintf(details, sizeof(details),
                         "Searched for '%s' in %s: %d matching lines",
                         word, source, matches);
                success = 1;
            }
        }
        break;

    case 5: /* List directory contents */
        {
            DIR *dir = opendir(directory);

            if (dir != NULL) {
                struct dirent *entry;
                int count = 0;

                while ((entry = readdir(dir)) != NULL) {
                    if (strcmp(entry->d_name, ".") != 0 &&
                        strcmp(entry->d_name, "..") != 0)
                        count++;
                }

                closedir(dir);

                snprintf(details, sizeof(details),
                         "Listed directory %s: %d entries",
                         directory, count);
                success = 1;
            }
        }
        break;
    }

    const char *task_names[TASK_COUNT] = {
        "Create File", "Delete File", "Copy File",
        "Display File Information", "Search for Word",
        "List Directory Contents"
    };

    if (success) {
        snprintf(message, sizeof(message),
                 "[%s] Child PID %ld | Task: %s | SUCCESS | %s",
                 timestamp, (long)getpid(),
                 task_names[task], details);
    } else {
        snprintf(message, sizeof(message),
                 "[%s] Child PID %ld | Task: %s | FAILED",
                 timestamp, (long)getpid(),
                 task_names[task]);
    }

    write_log(logfile, message);
    printf("%s\n", message);
}

int main(int argc, char *argv[])
{
    if (argc != 5) {
        fprintf(stderr,
                "Usage: %s <directory> <source_file> <search_word> <log_file>\n",
                argv[0]);
        return 1;
    }

    const char *directory = argv[1];
    const char *source = argv[2];
    const char *word = argv[3];
    const char *logfile = argv[4];

    struct stat info;

    if (stat(source, &info) != 0 || !S_ISREG(info.st_mode)) {
        fprintf(stderr, "Error: Source file does not exist: %s\n", source);
        return 1;
    }

    if (stat(directory, &info) != 0) {
        if (errno != ENOENT || mkdir(directory, 0755) != 0) {
            perror("Creating working directory");
            return 1;
        }
    } else if (!S_ISDIR(info.st_mode)) {
        fprintf(stderr, "Error: Working path is not a directory.\n");
        return 1;
    }

    long cores = sysconf(_SC_NPROCESSORS_ONLN);
    if (cores < 1) cores = 1;

    int child_count = (int)(cores / 2);
    if (child_count < 1) child_count = 1;

    /* Create the log file before starting children. */
    int logfd = open(logfile, O_WRONLY | O_CREAT | O_TRUNC, 0644);
    if (logfd < 0) {
        perror("Creating log file");
        return 1;
    }
    close(logfd);

    printf("Available CPU cores: %ld\n", cores);
    printf("Number of child processes: %d\n", child_count);
    printf("Starting parallel task execution...\n\n");

    pid_t *children = calloc(child_count, sizeof(pid_t));
    if (children == NULL) {
        perror("Memory allocation");
        return 1;
    }

    int started = 0;

    for (int i = 0; i < child_count; i++) {
        char delete_path[PATH_MAX];

        snprintf(delete_path, sizeof(delete_path),
                 "%s/delete_target_%d.txt", directory, i + 1);

        int seed = open(delete_path, O_WRONLY | O_CREAT | O_TRUNC, 0644);
        if (seed < 0) {
            perror("Creating delete test file");
            continue;
        }
        dprintf(seed, "Temporary file for deletion by child %d\n", i + 1);
        close(seed);

        pid_t pid = fork();

        if (pid < 0) {
            perror("fork");
            continue;
        }

        if (pid == 0) {
            unsigned int random_seed =
                (unsigned int)(time(NULL) ^ getpid());

            int task = rand_r(&random_seed) % TASK_COUNT;

            perform_task(task, i + 1, directory,
                         source, word, logfile);

            free(children);
            _exit(0);
        }

        children[i] = pid;
        started++;
    }

    int completed = 0;

    for (int i = 0; i < child_count; i++) {
        if (children[i] > 0) {
            int status;
            waitpid(children[i], &status, 0);
            completed++;
        }
    }

    free(children);

    printf("\nParent process PID: %ld\n", (long)getpid());
    printf("Child processes started: %d\n", started);
    printf("Child processes completed: %d\n", completed);
    printf("\nFinal execution log:\n");

    FILE *log = fopen(logfile, "r");
    if (log != NULL) {
        char line[1024];
        while (fgets(line, sizeof(line), log))
            printf("%s", line);
        fclose(log);
    }

    return 0;
}

