#!/bin/bash

LOGFILE="Installation.log"

echo "Starting system update..."
sudo apt update 2>> "$LOGFILE"

echo "Installing MySQL..."
sudo apt install mysql-server -y 2>> "$LOGFILE"

echo "Restarting MySQL..."
sudo systemctl restart mysql 2>> "$LOGFILE"

echo "System will be reloaded."

echo "Installing SSH..."
sudo apt install openssh-server -y 2>> "$LOGFILE"

echo "Installing FTP..."
sudo apt install vsftpd -y 2>> "$LOGFILE"

echo "Installing Apache..."
sudo apt install apache2 -y 2>> "$LOGFILE"

echo "Enabling services..."

sudo systemctl enable mysql 2>> "$LOGFILE"
sudo systemctl enable ssh 2>> "$LOGFILE"
sudo systemctl enable vsftpd 2>> "$LOGFILE"
sudo systemctl enable apache2 2>> "$LOGFILE"

echo "Checking services..."

sudo systemctl is-active mysql
sudo systemctl is-active ssh
sudo systemctl is-active vsftpd
sudo systemctl is-active apache2

echo "Task 2 completed successfully."
