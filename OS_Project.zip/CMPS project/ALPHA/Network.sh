#!/bin/bash

# Collect network information, test DNS, trace a route, and ping Google. Display and save all output.

set -u

LOG="$HOME/CMPS405/network.log"

mkdir -p "$HOME/CMPS405"

# Install required networking tools if any are missing.
if ! command -v ip >/dev/null 2>&1 ||
   ! command -v nslookup >/dev/null 2>&1 ||
   ! command -v traceroute >/dev/null 2>&1 ||
   ! command -v ping >/dev/null 2>&1; then

    echo "Installing required networking tools"
    sudo apt-get update &&
    sudo apt-get install -y iproute2 dnsutils traceroute iputils-ping

    if [ $? -ne 0 ]; then
        echo "ERROR: Could not install networking tools."
        exit 1
    fi
fi

# Save all output to the log while displaying it on screen.
exec > >(tee -a "$LOG") 2>&1

echo
echo "Network Diagnostics Report"
echo "Date: $(date '+%Y-%m-%d %H:%M:%S')"
echo "Hostname"

hostname

echo
echo "Network Interfaces and IP Configuration"

ip addr show

echo
echo "Routing Table"

ip route show

echo
echo "DNS Resolver Configuration"

if command -v resolvectl >/dev/null 2>&1; then
    resolvectl status
else
    cat /etc/resolv.conf
fi

echo
echo "DNS Lookup: google.com"

nslookup google.com
DNS_STATUS=$?

if [ "$DNS_STATUS" -eq 0 ]; then
    echo "DNS lookup completed successfully."
else
    echo "WARNING: DNS lookup failed."
fi

echo
echo "Traceroute to google.com"

traceroute -m 12 -w 2 google.com
TRACE_STATUS=$?

if [ "$TRACE_STATUS" -ne 0 ]; then
    echo "WARNING: Traceroute reported an error."
fi

echo
echo "Ping google.com"

ping -c 4 -W 2 google.com
PING_STATUS=$?

if [ "$PING_STATUS" -eq 0 ]; then
    echo "Ping completed successfully."
else
    echo "WARNING: Ping failed or received no replies."
fi

echo
echo "Network Diagnostics Finished"
echo "Log file: $LOG"
