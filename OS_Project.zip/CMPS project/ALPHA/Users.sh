#!/bin/bash

for i in {1..10}
do
    username="student$i"
    password="Password123"

    if id "$username" &>/dev/null
    then
        echo "$username already exists"
    else
        sudo useradd -m "$username"
        echo "$username:$password" | sudo chpasswd
        sudo usermod -aG sudo "$username"

        echo "$username created successfully"
    fi
done

