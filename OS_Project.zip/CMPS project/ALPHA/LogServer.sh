#!/bin/bash

# ALPHA Task 6: Centralized Syslog Server
# BETA IP address: 172.16.61.132

set -e

# This script must run with administrator privileges
if [ "$EUID" -ne 0 ]; then
    echo "Please run using sudo."
    exit 1
fi

# Save all setup output and errors in the required log file
exec > >(tee -a /var/log/logserver_setup.log) 2>&1

echo "Starting Log Server Setup: $(date)"

# Install and enable rsyslog
apt-get install -y rsyslog
systemctl enable rsyslog

# Create directory for incoming remote logs
mkdir -p /var/log/remote

# Configure UDP/TCP listeners and remote log storage
cat > /etc/rsyslog.d/10-cmps405-server.conf <<'EOF'
module(load="imudp")
input(type="imudp" port="514")

module(load="imtcp")
input(type="imtcp" port="514")

template(name="RemoteLogs" type="string"
         string="/var/log/remote/%HOSTNAME%/%HOSTNAME%.log")

if ($fromhost-ip != "127.0.0.1" and
    $fromhost-ip != "::1" and
    $fromhost-ip != "172.16.61.131") then {
    action(type="omfile" dynaFile="RemoteLogs"
           createDirs="on"
           dirCreateMode="0750"
           fileCreateMode="0640")
    stop
}
EOF

# Configure seven-day daily log rotation
cat > /etc/logrotate.d/cmps405-remote <<'EOF'
/var/log/remote/*/*.log {
    daily
    rotate 7
    missingok
    notifempty
    compress
    delaycompress
    create 0640 syslog adm
    sharedscripts
    postrotate
        /usr/lib/rsyslog/rsyslog-rotate
    endscript
}
EOF

# Validate configuration before restarting
rsyslogd -N1

# Allow SSH before enabling the firewall
ufw allow OpenSSH

# Only BETA may connect to syslog port 514
ufw allow from 172.16.61.132 to any port 514 proto udp
ufw allow from 172.16.61.132 to any port 514 proto tcp

# Restart logging service
systemctl restart rsyslog

# Generate a local test message
logger "CMPS405 ALPHA LogServer local test"

# Display final verification
echo "Listening ports:"
ss -tulnp | grep ':514'

echo "Firewall rules:"
ufw status verbose

echo "Final rsyslog service status:"
systemctl status rsyslog --no-pager

echo "Log Server Setup Completed: $(date)"
