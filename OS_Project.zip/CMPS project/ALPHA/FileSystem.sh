#!/bin/bash

# ALPHA Task 5: File System Auditing and Backup

# First subroutine: Collect system information
phase1() {
    echo "Starting Phase 1: System Information"

    # Save home directory disk usage in KB, sorted in reverse
    du -ak "$HOME" 2>/dev/null | sort -nr > /tmp/Disk_Usage.txt

    # Collect only the required CPU specifications
    lscpu | grep -E '^(Architecture:|CPU\(s\):|Model name:|Vendor ID:)' > /tmp/cpu_info.txt

    # Collect kernel messages about memory and disks
    if sudo dmesg > /tmp/all_kernel_messages.txt 2>/dev/null; then
        grep -Ei 'memory|mem|disk|sd[a-z]|nvme|ata[0-9]|virtio_blk' \
            /tmp/all_kernel_messages.txt > /tmp/Messages_Log.txt
    elif [ -r /var/log/kern.log ]; then
        grep -Ei 'memory|mem|disk|sd[a-z]|nvme|ata[0-9]|virtio_blk' \
            /var/log/kern.log > /tmp/Messages_Log.txt
    else
        echo "Error: Cannot access kernel logs" >&2
        return 1
    fi

    # Count words in memory and hard disk messages
    grep -Ei 'memory|mem' /tmp/Messages_Log.txt | wc -w > /tmp/Message_count.txt
    grep -Ei 'disk|sd[a-z]|nvme|ata[0-9]|virtio_blk' \
        /tmp/Messages_Log.txt | wc -w >> /tmp/Message_count.txt

    # Create a timestamped backup folder
    backup_dir="$HOME/CMPS405/$(date +%d%H%M%S)"
    mkdir -p "$backup_dir"

    # Compress the three required files
    tar -cjf "$backup_dir/Phase1.tar.bz2" \
        -C /tmp cpu_info.txt Messages_Log.txt Message_count.txt

    echo "Phase 1 backup saved to: $backup_dir"
}

phase1
# Second subroutine: Backup files with owner read and execute permissions
phase2() {
    echo "Starting Phase 2: File Permission Backup"

    # Create a backup folder named with the current date and time
    backup2="$HOME/CMPS405/$(date +%y%m%d%H%M%S)"
    mkdir -p "$backup2"

    # Find files with read and execute permissions for the owner only
    while IFS= read -r -d '' file; do
        # Keep the original directory structure in the backup
        relative="${file#"$HOME"/}"
        destination="$backup2/$relative"

        mkdir -p "$(dirname "$destination")"

        # Copy the file without changing the original
        cp -- "$file" "$destination"

        # Give only the owner read permission
        chmod 400 "$destination"

    done < <(find "$HOME" -path "$backup2" -prune -o \
        -type f -perm 500 -print0)

    # Restrict directory access to the owner
    find "$backup2" -type d -exec chmod 500 {} +

    echo "Phase 2 backup saved to: $backup2"
}

phase2
# Third subroutine: Verify the Phase 2 backup
phase3() {
    echo "Starting Phase 3: Backup Verification"

    # Check that Phase 2 has provided a backup directory
    if [ -z "${backup2:-}" ] || [ ! -d "$backup2" ]; then
        echo "Error: Phase 2 backup directory not found"
        return 1
    fi

    # Find files whose permissions are not exactly 400
    errors=0
    while IFS= read -r -d '' file; do
        echo "ERROR: Incorrect permissions: $file"
        errors=$((errors + 1))
    done < <(find "$backup2" -type f ! -perm 400 -print0)

    echo "Permission errors: $errors"

    # Display the total number of backed-up files
    total=$(find "$backup2" -type f | wc -l)
    echo "Total files backed up: $total"

    # Display backup directory size
    echo "Backup directory size:"
    du -sh "$backup2"

    # Display completion time
    echo "Execution completed at: $(date)"
}

phase3
