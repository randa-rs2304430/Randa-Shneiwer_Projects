
#!/bin/bash

# CMPS405 - Task 4: Log Forwarding Client

ALPHA_IP="172.16.61.133"
PORT="514"
CONFIG="/etc/rsyslog.d/90-forward-to-alpha.conf"

echo "======================================"
echo "       LOG FORWARDING CLIENT"
echo "======================================"

# 1. Check connectivity to ALPHA's syslog port
echo
echo "Checking ALPHA syslog port..."

if ! timeout 3 bash -c "echo > /dev/tcp/$ALPHA_IP/$PORT" 2>/dev/null; then
    echo "ERROR: Cannot reach ALPHA on TCP port $PORT."
    exit 1
fi

echo "ALPHA syslog port is reachable."

# 2. Check and set the BETA hostname
echo
echo "Checking hostname..."

CURRENT_HOST=$(hostname)

if [ "$CURRENT_HOST" != "BETA" ]; then
    echo "Setting hostname to BETA..."
    sudo hostnamectl set-hostname BETA || exit 1
else
    echo "Hostname is already BETA."
fi

# 3. Ensure rsyslog is installed
echo
echo "Checking rsyslog installation..."

if ! command -v rsyslogd >/dev/null 2>&1; then
    echo "Installing rsyslog..."
    sudo apt-get update && sudo apt-get install -y rsyslog || exit 1
else
    echo "rsyslog is already installed."
fi

# 4. Configure TCP forwarding if not already configured
echo
echo "Checking forwarding configuration..."

if ! grep -q 'target="172.16.61.133"' "$CONFIG" 2>/dev/null ||
   ! grep -q 'protocol="tcp"' "$CONFIG" 2>/dev/null; then

    echo "Creating TCP forwarding configuration..."

    sudo tee "$CONFIG" > /dev/null <<'EOF'
# Forward all system logs to ALPHA
*.* action(
    type="omfwd"
    target="172.16.61.133"
    port="514"
    protocol="tcp"
    action.resumeRetryCount="-1"
    queue.type="LinkedList"
    queue.size="10000"
)
EOF
else
    echo "Correct TCP forwarding configuration already exists."
fi

# 5. Validate configuration
echo
echo "Validating rsyslog configuration..."

if ! sudo rsyslogd -N1; then
    echo "ERROR: Invalid rsyslog configuration."
    exit 1
fi

# 6. Enable and restart rsyslog
echo
echo "Restarting rsyslog..."

sudo systemctl enable --now rsyslog || exit 1
sudo systemctl restart rsyslog || exit 1

echo "rsyslog is running."

# 7. Generate a test log message
echo
echo "Generating test log message..."

logger -p user.notice -t CMPS405-LOGCLIENT \
    "Log forwarding test generated on BETA at $(date)"

echo "Test message generated."

# 8. Generate a sudo event
echo
echo "Generating sudo test event..."
sudo /usr/bin/id

echo
echo "======================================"
echo "LOG CLIENT CONFIGURATION COMPLETED"
echo "======================================"

