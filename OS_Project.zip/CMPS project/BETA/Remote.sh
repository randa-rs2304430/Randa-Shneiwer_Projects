
#!/bin/bash

# CMPS405 - Task 2: Remote Access and Web Verification

ALPHA_IP="172.16.61.133"
ALPHA_USER="student1"
WEB_PAGE="http://$ALPHA_IP/index.html"

REPORT=$(ls -t "$HOME"/CMPS405/sysinfo_report_*.txt 2>/dev/null | head -n 1)

echo "======================================"
echo " REMOTE ACCESS AND WEB VERIFICATION"
echo "======================================"

# Check that a system report exists
if [ -z "$REPORT" ]; then
    echo "ERROR: No system information report found."
    exit 1
fi

echo "System report: $REPORT"

# Test SSH connection
echo
echo "Testing SSH connection to ALPHA..."

if ! ssh -o BatchMode=yes -o ConnectTimeout=5 \
    "$ALPHA_USER@$ALPHA_IP" "hostname"; then
    echo "ERROR: SSH connection to ALPHA failed."
    exit 1
fi

echo "SSH connection successful."

# Verify ALPHA web page
echo
echo "Checking ALPHA web page..."

SAVED_PAGE="$HOME/CMPS405/ALPHA_index.html"

if wget -q -O "$SAVED_PAGE" "$WEB_PAGE" && [ -s "$SAVED_PAGE" ]; then
    echo "Web page downloaded successfully."
    echo "Saved page: $SAVED_PAGE"
else
    echo "ERROR: ALPHA web page could not be downloaded."
    exit 1
fi

# Transfer report using SFTP
echo
echo "Transferring system report to ALPHA..."

if sftp -oBatchMode=yes "$ALPHA_USER@$ALPHA_IP" <<EOF
put "$REPORT"
EOF
then
    echo "Report transferred successfully."
else
    echo "ERROR: SFTP transfer failed."
    exit 1
fi

echo
echo "======================================"
echo "REMOTE TASK COMPLETED"
echo "======================================"

