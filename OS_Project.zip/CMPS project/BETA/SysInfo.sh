
#!/bin/bash

# CMPS405 - Task 3: System Information Report

REPORT="$HOME/CMPS405/sysinfo_report_$(date +%Y%m%d_%H%M%S).txt"

{
    echo "=========================================="
    echo "       SYSTEM INFORMATION REPORT"
    echo "=========================================="
    echo "Hostname: $(hostname)"
    echo "Date and Time: $(date)"
    echo "Username: $(whoami)"
    echo

    echo "========== CPU INFORMATION =========="
    lscpu
    echo

    echo "========== MEMORY INFORMATION =========="
    free -h
    echo

    echo "========== DISK INFORMATION =========="
    df -hT
    echo

    echo "========== NETWORK INTERFACE INFORMATION =========="
    ip -details link
    echo
    ip addr
    echo
    ip route
    echo

    echo "========== INSTALLED APPLICATIONS =========="
    dpkg-query -W -f='${binary:Package}\t${Version}\n' 2>/dev/null
    echo

    echo "=========================================="
    echo "Report generated successfully."
    echo "=========================================="

} > "$REPORT"

echo "System information report created:"
echo "$REPORT"
echo
echo "Report size:"
du -h "$REPORT"

