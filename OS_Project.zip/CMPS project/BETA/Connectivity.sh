#!/bin/bash

# CMPS405 - BETA Task 1
# Test connectivity to ALPHA every 5 minutes.
# Each execution appends a timestamp and the ping result.

ALPHA_IP="172.16.61.133"
LOG_FILE="/tmp/SecondVM.txt"

{
    echo "===== $(date '+%Y-%m-%d %H:%M:%S') ====="
    if ping -c 1 -W 3 "$ALPHA_IP"; then
        echo "Connectivity: SUCCESS"
    else
        echo "Connectivity: FAILED"
    fi
    echo
} >> "$LOG_FILE" 2>&1
