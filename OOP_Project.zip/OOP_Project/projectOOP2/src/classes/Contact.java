package classes;

import java.io.Serializable;

/**
 * Represents contact information for a person, including email and phone number.
 * @author Khwla
 */
public class Contact implements Serializable {
	/**
	 * Default serial Version Id
	 */
	private static final long serialVersionUID = 1L;
	private String email;
	private String phoneNumber;

	/**
	 * Constructs a Contact object with the specified email and phone number.
	 *
	 * @param email       The email address.
	 * @param phoneNumber The phone number.
	 */
	public Contact(String email, String phoneNumber) {
		setEmail(email);
		setPhoneNumber(phoneNumber);
	}
	public Contact() {
        // no-arg constructor required for deserialization
    }

	/**
	 * Gets the email address.
	 *
	 * @return The email address.
	 */
	public String getEmail() {
		return email;
	}

	/**
	 * Sets the email address.
	 *
	 * @param email The email address to set.
	 */
	public void setEmail(String email) {
		this.email = email;
	}

	/**
	 * Gets the phone number.
	 *
	 * @return The phone number.
	 */
	public String getPhoneNumber() {
		return phoneNumber;
	}

	/**
	 * Sets the phone number.
	 *
	 * @param phoneNumber The phone number to set.
	 */
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	/**
	 * Displays the contact information (email and phone number).
	 */
	public void displayContactInfo() {
		System.out.println(getEmail());
		System.out.println(getPhoneNumber());
	}

	/**
	 * Returns a string representation of the contact.
	 *
	 * @return A string containing email and phone number.
	 */
	@Override
	public String toString() {
		return "Contact [email=" + email + ", phoneNumber=" + phoneNumber + "]";
	}
}
