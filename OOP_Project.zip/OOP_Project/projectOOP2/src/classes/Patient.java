package classes;

import java.io.Serializable;

/**
 * Represents a patient in the hospital system.
 * Inherits from the Person class and adds specific attributes like age and medical history.
 * @author randa,Khwla
 */
public class Patient extends Person implements Serializable {
    /**
	 * Default serial Version Id
	 */
	private static final long serialVersionUID = 1L;
	private int age;
    private String medicalHistory;

    /**
     * Constructs a new Patient object with the given attributes.
     *
     * @param id             the unique ID of the patient
     * @param name           the name of the patient
     * @param contact        the contact information of the patient
     * @param gender         the gender of the patient
     * @param age            the age of the patient
     * @param medicalHistory the medical history of the patient
     */
    public Patient(int id, String name, Contact contact, Gender gender, int age, String medicalHistory) {
        super(id, name, contact, gender);
        setAge(age);
        setMedicalHistory(medicalHistory);
    }
    public Patient() {
    	
        // no-arg constructor required for deserialization
    }

    /**
     * Returns the age of the patient.
     *
     * @return the age
     */
    public int getAge() {
        return age;
    }

    /**
     * Sets the age of the patient.
     *
     * @param age the age to set
     */
    public void setAge(int age) {
        this.age = age;
    }

    /**
     * Returns the medical history of the patient.
     *
     * @return the medical history
     */
    public String getMedicalHistory() {
        return medicalHistory;
    }

    /**
     * Sets the medical history of the patient.
     *
     * @param medicalHistory the medical history to set
     */
    public void setMedicalHistory(String medicalHistory) {
        this.medicalHistory = medicalHistory;
    }

    /**
     * Appends new information to the existing medical history.
     *
     * @param newMedicalInfo the new medical information to add
     */
    public void updateMedicalHistory(String newMedicalInfo) {
        if (newMedicalInfo != null && !newMedicalInfo.trim().isEmpty()) {
            this.medicalHistory += "\n" + newMedicalInfo;
            System.out.println("Medical history updated.");
        } else {
            System.out.println("Invalid medical info. Update failed.");
        }
    }

    /**
     * Displays the details of the patient.
     */
    @Override
    public void displayDetails() {
        System.out.println(toString());
    }

    /**
     * Returns a string representation of the patient, including personal details,
     * age, and medical history.
     *
     * @return a string with patient information
     */
    @Override
    public String toString() {
        return"Patient ["+super.toString() +",age=" + age + ", medicalHistory=" + medicalHistory + "]";
    }
}
