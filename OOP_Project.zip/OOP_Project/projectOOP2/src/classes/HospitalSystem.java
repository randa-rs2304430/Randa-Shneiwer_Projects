package classes;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;


/**
 * The HospitalSystem class manages the core functionalities of the hospital system,
 * including managing patients, doctors, appointments, departments, and billing.
 * It also provides methods to save and load data from files.
 * @author Khwla,randa
 */

public class HospitalSystem implements Payable, Serializable  {
	/**
	 * Default serial Version Id
	 */
	private static final long serialVersionUID = 1L;
	private int nextPatientId = 1000;
	private int nextDoctorId = 2000;
	private int nextAppointmentId = 3000; 
	private int nextBillId =4000;
	
	private ArrayList<Patient> patients = new ArrayList<>() ;
	private ArrayList<Doctor> doctors = new ArrayList<>();
	private ArrayList<Appointment> appointments = new ArrayList<>();
	private ArrayList<Bill> bills = new ArrayList<>();
	private ArrayList<Department> departments = new ArrayList<>();
	
	private final static String patientsFile = "src/patinetsFile";
    private final String doctorsFile = "src/doctorsFile";
    private final String appointmentsFile = "src/appointmentsFile";
    private final String billsFile = "src/billsFile";
    private final String departmentsFile = "src/departmentsFile";
    private final String countersFile = "src/countersFile";

   
	/** Default constructor */
	public HospitalSystem() {
		File f1 = new File(patientsFile);
		File f2 = new File(doctorsFile);
		File f3 = new File(appointmentsFile);
		File f4 = new File(billsFile);
		File f5 = new File(departmentsFile);
		File f6 = new File(countersFile);
		if(f1.exists() && f2.exists() && f3.exists() && f4.exists() && f5.exists() && f6.exists()) {
			loadDataFromFile();
		}
	}
	
	
	/** @return list of all patients */
	public ArrayList<Patient> getPatients() {
		return patients;
	}


	/**
	 * @return list of all doctors
	 */
	public ArrayList<Doctor> getDoctors() {
		return doctors;
	}


	/**
	 * @return list of all appointments 
	 */
	public ArrayList<Appointment> getAppointments() {
		return appointments;
	}


	/**
	 * @return list of all bills
	 */
	public ArrayList<Bill> getBills() {
		return bills;
	}


	/**
	 * @return list of all departments
	 */
	public ArrayList<Department> getDepartments() {
		return departments;
	}

	/**
	 *  @return next available patient ID
	 */
	public int getNextPatientId() {
		return nextPatientId+=1;
	}
	
	/** 
	 * @return next available doctor ID 
	 */
	public int getNextDoctorId() {
		return nextDoctorId++;
	}
	
	/**
	 *  @return next available appointment ID
	 */
	public int getNextAppointmentId() {
		return nextAppointmentId++;
	}
	
	public int getNextBillId() {
        return nextBillId++;
    }
	
	/** Adds a patient to the system */
	public void addPatient(Patient patient) {
		patients.add(patient);
		
	}
	
	/** 
	 Deletes a patient by ID 
	*/
	public void deletePatient(int patientId) {
		for (Patient patient: patients) {
			if (patient.getId()==patientId) {
				patients.remove(patient);
			}
		}
		
	}
	
	/** Searches for a patient by ID */
	public Patient searchPatientById(int patientId) {
		for (Patient patient:patients ) {
			if (patient.getId()==patientId) {	
				return patient;
			}
		}
	return null;
	}
	
	/** Adds a doctor to the system */
	public void addDoctor(Doctor doctor) {
		doctors.add(doctor);
	}
	
	/** Deletes a doctor by ID */
	public void deleteDoctor(int doctorId) {
		for (Doctor doctor :doctors) {
			if (doctor.getId()==doctorId) {
				doctors.remove(doctor);
			}
		}
	}
	
	/** Searches for a doctor by ID */
	public Doctor searchDoctorById(int doctorId) {
		for (Doctor doctor :doctors) {
			if (doctor.getId()== doctorId) {
				return doctor;
			}
		}
		return null;
		}
	
	/**
	 * Schedules a new appointment if no conflict exists.
	 * @return true if scheduled successfully, false if there is a conflict.
	 */
	
	public boolean scheduleAppointment(Appointment newAppointment) {
		Patient patient = searchPatientById(newAppointment.getPatientID());
		Doctor doctor = searchDoctorById(newAppointment.getDoctorID());
		if (patient == null || doctor == null) {
	        return false;
	    }

	    // Check for conflicts with existing appointments
	    for (Appointment appointment : doctor.getAppointments()) {
	        if (appointment.getAppointmentDate().equals(newAppointment.getAppointmentDate())) {
	            return false; // Conflict exists
	        }
	    }

	    // No conflict found; add appointment
	    appointments.add(newAppointment);
	    doctor.getAppointments().add(newAppointment);
	    return true;}
	
	/**
	 * Cancels an appointment by ID.
	 * @return true if canceled successfully.
	 */
	
	public boolean cancelAppointmentByID(int appointmentId) {
		for (Appointment appointment:appointments ) {
			if (appointment.getAppointmentID()==appointmentId) {
				appointment.cancelAppointment();
				appointments.remove(appointment);
				return true;
				}
			
		} return false;
		
	}
	
	/** Searches for an appointment by ID */
	public Appointment searchAppointmentByID(int appointmentId) {
		for (Appointment appointment: appointments) {
			if (appointment.getAppointmentID()==appointmentId) {
				return appointment;
			}
		} return null;
		}
	
	/** Generates and adds a bill to the system */
	public void generateBill(Bill bill) {
		bills.add(bill);
		bill.generateInvoice();
	}
	
	public void addBill(Bill bill) {
        bills.add(bill);
    }
	
	/** Searches for a bill by ID */
	public Bill searchBillById (int billId) {
		for (Bill bill:bills) {
			if (bill.getBillId()==billId) {
				return bill;
			}
			
		} return null;
	}
	
	/** Calculates the payment for a bill with insurance deduction */
	public double calculatePayment(int billId) {
		Bill bill = searchBillById(billId);
		if (bill != null) {
			return 0.3*bill.calculatePayment(billId);
		}
		return 0;
	}
	
	
	/** Adds a department to the system */
	public void addDepartment(Department department) {
		departments.add(department);
		
	}
	
	/** Assigns a doctor to a department */
	public void assignDoctorToDepartment(int depId, int docId) {
	for (Department department: departments) {
		if (department.getDepartmentId()==depId) {
			for (Doctor doctor:doctors) {
				if (doctor.getId()==docId) {
					department.getDoctorsInThisDepartment().add(doctor);
					doctor.setDepartment(department);break;
				}
				
			}
			
			}
		}
	}

	/** Displays report for all patients */
	public void generatePatientReport() {
		System.out.println("Patient Report:");
		for (Patient patient : patients) {
			patient.displayDetails();
		}
	
		
	}
	
	/** Displays report for all doctors */
	public void generateDoctorReport() {
		System.out.println("Doctor Report:");
		for (Doctor doctor : doctors) {
			doctor.displayDetails();
		}
	}
	
	public void generateAppointmentReport() {
		System.out.println("Appointment Report:");
		for (Appointment appointment : appointments) {
			System.out.println(appointment);
		}
	}
	
	/** Displays report for all appointments */
	public void generateBillingReport() {
		System.out.println("Billing Report:");
		double revenue = 0;
		for (Bill bill : bills) {
			System.out.println(bill);
			revenue +=bill.calculatePayment(bill.getBillId());
		}
		System.out.println("Total revenue is " +revenue + "QR.");
	}
	
	/** Displays report for all departments */
	public void generateDepartmentReport() {
		System.out.println("Department Report:");
		for (Department department : departments) {
			department.displayDepartmentDetails();
		}
	}
	
	/** Saves all data to corresponding files */
	 public void saveDataToFiles() {
	        try (
	            ObjectOutputStream outPatients = new ObjectOutputStream(new FileOutputStream(patientsFile));
	            ObjectOutputStream outDoctors = new ObjectOutputStream(new FileOutputStream(doctorsFile));
	            ObjectOutputStream outDepartments = new ObjectOutputStream(new FileOutputStream(departmentsFile));
	            ObjectOutputStream outBills = new ObjectOutputStream(new FileOutputStream(billsFile));
	            ObjectOutputStream outAppointments = new ObjectOutputStream(new FileOutputStream(appointmentsFile));
	            DataOutputStream outCounters = new DataOutputStream(new FileOutputStream(countersFile))
	        ) {
	            outPatients.writeObject(patients);
	            outDoctors.writeObject(doctors);
	            outDepartments.writeObject(departments);
	            outBills.writeObject(bills);
	            outAppointments.writeObject(appointments);

	            outCounters.writeInt(nextPatientId);
	            outCounters.writeInt(nextAppointmentId);
	            outCounters.writeInt(nextDoctorId);
	            outCounters.writeInt(nextBillId);
	        } catch (IOException e) {
	            e.printStackTrace();
	        }
	    }
	

	/** Loads all data from corresponding files */
	 public void loadDataFromFile() {
	        try (
	            ObjectInputStream inPatients = new ObjectInputStream(new FileInputStream(patientsFile));
	            ObjectInputStream inDoctors = new ObjectInputStream(new FileInputStream(doctorsFile));
	            ObjectInputStream inDepartments = new ObjectInputStream(new FileInputStream(departmentsFile));
	            ObjectInputStream inBills = new ObjectInputStream(new FileInputStream(billsFile));
	            ObjectInputStream inAppointments = new ObjectInputStream(new FileInputStream(appointmentsFile));
	            DataInputStream inCounters = new DataInputStream(new FileInputStream(countersFile))
	        ) {
	            patients = (ArrayList<Patient>) inPatients.readObject();
	            doctors = (ArrayList<Doctor>) inDoctors.readObject();
	            departments = (ArrayList<Department>) inDepartments.readObject();
	            bills = (ArrayList<Bill>) inBills.readObject();
	            appointments = (ArrayList<Appointment>) inAppointments.readObject();

	            nextPatientId = inCounters.readInt();
	            nextAppointmentId = inCounters.readInt();
	            nextDoctorId = inCounters.readInt();
	            nextBillId = inCounters.readInt();
	        } catch (IOException | ClassNotFoundException e) {
	            e.printStackTrace();
	        }
	    }
}

