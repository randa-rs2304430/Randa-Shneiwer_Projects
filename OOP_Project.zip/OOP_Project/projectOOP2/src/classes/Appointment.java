package classes;
import java.io.Serializable;
import java.time.LocalDate;

/**
 * Represents an appointment between a patient and a doctor.
 * Contains details such as appointment ID, patient ID, doctor ID,
 * date of appointment, and status of the appointment.
 *  @author Haneen
 */
	public class Appointment implements Serializable {
	/**
	 * Default serial Version Id
	 */
	private static final long serialVersionUID = 1L;
		public int appointmentID;
		public int patientID;
		public int doctorID;
		public LocalDate appointmentDate;
		public AppointmentStatus appointmentStatus;
		
		/**
		 * Constructs a new Appointment with the given parameters.
		 *
		 * @param appointmentID   the unique ID of the appointment
		 * @param patientID       the ID of the patient
		 * @param doctorID        the ID of the doctor
		 * @param appointmentDate the date of the appointment
		 */
		
		public Appointment(int appointmentID, int patientID, int doctorID, LocalDate appointmentDate) {
			this.appointmentID=appointmentID;
			this.patientID = patientID;
	        this.doctorID = doctorID;
	        this.appointmentDate = appointmentDate;
	        this.appointmentStatus = AppointmentStatus.UNKNOWN;
	        
		}
		 public Appointment() {
		        // no-arg constructor required for deserialization
		    }
		
		/**
		 * @return the appointment ID
		 */
		
		public int getAppointmentID() {
			return appointmentID;
		}
		
		/**
		 * Sets the appointment ID.
		 *
		 * @param appointmentID the appointment ID to set
		 */
		public void setAppointmentID(int appointmentID) {
			this.appointmentID = appointmentID;
		}
		
		/**
		 * @return the patient ID associated with this appointment
		 */
		public int getPatientID() {
			return patientID;
		}
		
		/**
		 * Sets the patient ID.
		 *
		 * @param patientID the patient ID to set
		 */
		public void setPatientID(int patientID) {
			this.patientID = patientID;
		}
		
		/**
		 * @return the doctor ID associated with this appointment
		 */
		public int getDoctorID() {
			return doctorID;
		}
		
		/**
		 * Sets the doctor ID.
		 *
		 * @param doctorID the doctor ID to set
		 */
		public void setDoctorID(int doctorID) {
			this.doctorID = doctorID;
		}
		
		/**
		 * @return the date of the appointment
		 */
		public LocalDate getAppointmentDate() {
			return appointmentDate;
		}
		
		/**
		 * Sets the date of the appointment.
		 *
		 * @param appointmentDate the date to set
		 */
		public void setAppointmentDate(LocalDate appointmentDate) {
			this.appointmentDate = appointmentDate;
		}
		
		/**
		 * @return the status of the appointment
		 */

		public AppointmentStatus getAppointmentStatus() {
			return appointmentStatus;
		}
		
		/**
		 * Sets the status of the appointment.
		 *
		 * @param appointmentStatus the new status
		 */
		public void setAppointmentStatus(AppointmentStatus appointmentStatus) {
			this.appointmentStatus = appointmentStatus;
		}
		
		/**
		 * Confirms the appointment by setting its status to CONFIRMED.
		 */
		public void confirmAppointment() {
			this.appointmentStatus=AppointmentStatus.CONFIRMED;
				}
		
		/**
		 * Cancels the appointment by setting its status to CANCELLED.
		 */
		public void cancelAppointment() {
			this.appointmentStatus=AppointmentStatus.CANCELLED;
				}
		
		/**
		 * Reschedules the appointment to a new date.
		 *
		 * @param newDate the new date for the appointment
		 */
		public void rescheduleAppointment(LocalDate newDate) {
			this.appointmentDate=newDate;		
		}
		
		/**
		 * Returns a string representation of the appointment.
		 *
		 * @return string with appointment details
		 */
		@Override
		public String toString() {
			return "Appointment [appointmentID=" + appointmentID + ", patientID=" + patientID + ", doctorID=" + doctorID
					+ ", appointmentDate=" + appointmentDate + ", appointmentStatus=" + appointmentStatus + "]";
		}
		
		

		
		

	}


