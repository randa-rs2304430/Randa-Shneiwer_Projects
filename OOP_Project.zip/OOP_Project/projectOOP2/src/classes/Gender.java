package classes;

/**
 * Enum representing gender values for individuals in the hospital system.
 */
public enum Gender {
    /** Female gender. */
    FEMALE,
    
    /** Male gender. */
    MALE;
}