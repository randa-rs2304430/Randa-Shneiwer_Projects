package classes;

/**
 * Enum representing the possible statuses of an appointment.
 * @author Haneen
 */
public enum AppointmentStatus {
	
	/**
	 * Indicates that the appointment has been confirmed.
	 */
	CONFIRMED,
	
	/**
	 * Indicates that the appointment has been cancelled.
	 */
	CANCELLED,
	
	/**
	 * Indicates that the appointment status is unknown or not yet set.
	 */
	UNKNOWN;
}