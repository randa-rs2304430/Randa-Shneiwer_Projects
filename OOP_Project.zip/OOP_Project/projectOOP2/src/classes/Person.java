package classes;

import java.io.Serializable;

/**
 * Represents a general person in the hospital system.
 * This class is abstract and meant to be extended by specific roles such as Patient or Doctor.
 * @author randa,Khwla
 */
public abstract class Person implements Serializable {
    /**
	 * Default serial Version Id
	 */
	private static final long serialVersionUID = 1L;
	private int id;
    private String name;
    private Contact contact;
    private Gender gender;

    /**
     * Constructs a Person object with the specified details.
     *
     * @param id      the unique identifier for the person
     * @param name    the name of the person
     * @param contact the contact details of the person
     * @param gender  the gender of the person
     */
    public Person(int id, String name, Contact contact, Gender gender) {
        setId(id);
        setName(name);
        setContact(contact);
        setGender(gender);
    }
    public Person() {
        // no-arg constructor required for deserialization
    }

    /**
     * Gets the ID of the person.
     *
     * @return the person's ID
     */
    public int getId() {
        return id;
    }

    /**
     * Sets the ID of the person.
     *
     * @param id the ID to set
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * Gets the name of the person.
     *
     * @return the person's name
     */
    public String getName() {
        return name;
    }

    /**
     * Sets the name of the person.
     *
     * @param name the name to set
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * Gets the contact details of the person.
     *
     * @return the contact object
     */
    public Contact getContact() {
        return contact;
    }

    /**
     * Sets the contact details of the person.
     *
     * @param contact the contact object to set
     */
    public void setContact(Contact contact) {
        this.contact = contact;
    }

    /**
     * Gets the gender of the person.
     *
     * @return the person's gender
     */
    public Gender getGender() {
        return gender;
    }

    /**
     * Sets the gender of the person.
     *
     * @param gender the gender to set
     */
    public void setGender(Gender gender) {
        this.gender = gender;
    }

    /**
     * Updates the person's contact information.
     *
     * @param newContact the new contact object
     */
    public void updateContactInfo(Contact newContact) {
        if (newContact != null) {
            this.contact = newContact;
            System.out.println("Contact information updated successfully.");
        } else {
            System.out.println("Failed to update: new contact is null.");
        }
    }

    /**
     * Validates the provided ID.
     *
     * @param id the ID to validate
     * @return true if the ID is positive, false otherwise
     */
    public boolean validDateId(int id) {
        return id > 0;
    }

    /**
     * Displays the detailed information of the person.
     * Must be implemented by subclasses.
     */
    public abstract void displayDetails();

    /**
     * Returns a string representation of the person.
     *
     * @return a formatted string with person details
     */
    @Override
    public String toString() {
        return "id=" + id + ", name=" + name + ", contact=" + contact + ", gender=" + gender ;
    }
}
