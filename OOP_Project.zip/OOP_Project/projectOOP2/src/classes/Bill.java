package classes;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.ArrayList;

/**
 * Represents a bill issued to a patient for services rendered in the hospital.
 * Implements the {@link Payable} interface.
 * @author Wadha
 */
public class Bill implements Payable,Serializable {
	private static final long serialVersionUID = 1L;

	private int billId;
	private int patientId;
	private double amount =100;
	/**
	 * @return the amount
	 */
	public double getAmount() {
		return amount;
	}
	/**
	 * @param amount the amount to set
	 */
	public void setAmount(double amount) {
		this.amount = amount;
	}

	private ArrayList<String> services;
	private LocalDate date;

	/**
	 * Constructs a new Bill object.
	 *
	 * @param billId    The unique ID of the bill.
	 * @param patientId The ID of the patient associated with the bill.
	 * @param totalCost      The date the bill was created.
	 */
	public Bill(int billId, int patientId, LocalDate Date,ArrayList<String> services) {
		this.billId = billId;
		this.patientId = patientId;
		this.date = Date;
		this.services = services;
		
	}
	 public Bill() {
	        // no-arg constructor required for deserialization
	    }

	/**
	 * Adds a service to the list of services billed.
	 *
	 * @param service A description of the service provided.
	 */
	public void addService(String service) {
		services.add(service);
	}

	/**
	 * Prints a formatted invoice to the console for this bill.
	 */
	public void generateInvoice() {
		System.out.println("Invoice for Bill ID: " + billId);
		System.out.println("Patient ID: " + patientId);
		System.out.println("Date: " + date);
		System.out.println("Services Provided: " + services);
		System.out.println("Total Amount: $" + calculatePayment(billId));
	}

	/**
	 * Calculates the total payment amount for this bill.
	 * This method currently just returns the stored amount.
	 *
	 * @param billId The ID of the bill for which payment is calculated.
	 * @return The payment amount.
	 */
	public double calculatePayment(int billId) {
		return amount; 
	}

	/**
	 * Gets the bill ID.
	 *
	 * @return The bill ID.
	 */
	public int getBillId() {
		return billId;
	}
	@Override
	public String toString() {
		return "Bill [billId=" + billId + ", patientId=" + patientId + ", amount=" + amount + ", services=" + services
				+ ", date=" + date + "]";
	}
	
}