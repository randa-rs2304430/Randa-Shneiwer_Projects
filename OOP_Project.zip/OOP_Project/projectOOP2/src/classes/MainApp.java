package classes;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Scanner;

/**
 * The entry point of the Hospital Management System.
 * Provides a menu-driven console interface for managing patients, doctors, departments,
 * appointments, and billing.
 * @author randa,Khwla
 */
public class MainApp {
    /** Menu text for user interaction */
    static String menu = "\t=== Hospital Management Menu ===\n" +
            "1. Add Patient\t\t2. Add Doctor\n" +
            "3. Add Department\t4. Assign Doctor to Department\n" +
            "5. Schedule Appointment\t6. Generate Bill\n" +
            "7. Show Reports\t\t8. Show All Doctors\n" +
            "9. Show All Departments\t10. Save and Exit\n";

    private static Scanner scanner = new Scanner(System.in);
    private static HospitalSystem hospitalSystem = new HospitalSystem();

    /**
     * The main method that starts the application loop.
     * @param args Command-line arguments (not used).
     */
    public static void main(String[] args) {
        boolean running = true;

        while (running) {
            try {
                System.out.println(menu);
                System.out.print("Enter your option: ");
                int option = scanner.nextInt();
                scanner.nextLine(); // Consume newline

                switch (option) {
                    case 1: addPatient(); break;
                    case 2: addDoctor(); break;
                    case 3: addDepartment(); break;
                    case 4: assignDoctorToDepartment(); break;
                    case 5: scheduleAppointment(); break;
                    case 6: generateBill(); break;
                    case 7: showReports(); break;
                    case 8: showAllDoctors(); break;
                    case 9: showAllDepartments(); break;
                    case 10:
                        System.out.println("Exiting System...");
                        running = false;
                        hospitalSystem.saveDataToFiles();
                        System.exit(0);
                        break;
                    default:
                        System.out.println("Invalid option.");
                }
            } catch (Exception e) {
                System.out.println("Error: " + e.getMessage());
                scanner.nextLine(); // Clear input buffer
            }
        }
        scanner.close();
    }

    /**
     * Adds a new patient to the system by collecting user input.
     */
    private static void addPatient() {
        System.out.print("Name: ");
        String name = scanner.nextLine();
        System.out.print("Email: ");
        String email = scanner.nextLine();
        System.out.print("Phone Number: ");
        String phoneNumber = scanner.nextLine();
        Contact contact = new Contact(email, phoneNumber);

        System.out.print("Gender (M/F): ");
        String genderInput = scanner.nextLine().toUpperCase();
        Gender gender = genderInput.startsWith("M") ? Gender.MALE : Gender.FEMALE;

        System.out.print("Age: ");
        int age = scanner.nextInt();
        scanner.nextLine();

        System.out.print("Medical History: ");
        String medicalHistory = scanner.nextLine();

        int patientId = hospitalSystem.getNextPatientId();
        Patient patient = new Patient(patientId, name, contact, gender, age, medicalHistory);
        hospitalSystem.addPatient(patient);

        System.out.println("A new patient is added successfully.\n");
    }

    /**
     * Adds a new doctor to the system and assigns them to a department.
     */
    private static void addDoctor() {
        System.out.print("Name: ");
        String name = scanner.nextLine();
        System.out.print("Email: ");
        String email = scanner.nextLine();
        System.out.print("Phone Number: ");
        String phoneNumber = scanner.nextLine();
        Contact contact = new Contact(email, phoneNumber);

        System.out.print("Gender (M/F): ");
        String genderInput = scanner.nextLine().toUpperCase();
        Gender gender = genderInput.startsWith("M") ? Gender.MALE : Gender.FEMALE;

        System.out.print("Specialization: ");
        String specialization = scanner.nextLine();

        int doctorId = hospitalSystem.getNextDoctorId();
        Doctor doctor = new Doctor(doctorId, name, contact, gender, specialization);
        hospitalSystem.addDoctor(doctor);

        System.out.print("Department ID: ");
        int departmentId = scanner.nextInt();
        scanner.nextLine();

        hospitalSystem.assignDoctorToDepartment(departmentId, doctorId);
        System.out.println("A new doctor is added and assigned to department successfully.\n");
    }

    /**
     * Adds a new department to the system.
     */
    private static void addDepartment() {
        System.out.print("Department Name: ");
        String depName = scanner.nextLine();

        System.out.print("Department ID: ");
        int depId = scanner.nextInt();
        scanner.nextLine();

        Department department = new Department(depId, depName);
        hospitalSystem.addDepartment(department);

        System.out.println("A new department is added successfully.\n");
    }

    /**
     * Assigns an existing doctor to an existing department.
     */
    private static void assignDoctorToDepartment() {
        System.out.print("Doctor ID: ");
        int docId = scanner.nextInt();
        System.out.print("Department ID: ");
        int depId = scanner.nextInt();
        scanner.nextLine();

        hospitalSystem.assignDoctorToDepartment(depId, docId);
        System.out.printf("Doctor with ID %d is assigned to department %d.\n", docId, depId);
    }

    /**
     * Schedules an appointment for a patient with a doctor.
     */
    private static void scheduleAppointment() {
        try {
            System.out.print("Patient ID: ");
            int patientId = scanner.nextInt();
            System.out.print("Doctor ID: ");
            int doctorId = scanner.nextInt();
            scanner.nextLine();

            System.out.print("Appointment Date (yyyy-mm-dd): ");
            String dateInput = scanner.nextLine();
            LocalDate date = LocalDate.parse(dateInput);

            int appointmentId = hospitalSystem.getNextAppointmentId();
            Appointment appointment = new Appointment(appointmentId, patientId, doctorId, date);

            if (hospitalSystem.scheduleAppointment(appointment)) {
                System.out.println("Appointment scheduled successfully.");
            } else {
                System.out.println("Failed to schedule appointment.");
                if (hospitalSystem.searchPatientById(patientId) == null)
                    System.out.println("Check Patient ID.");
                else if (hospitalSystem.searchDoctorById(doctorId) == null)
                    System.out.println("Check Doctor ID.");
                else
                    System.out.println("The doctor is not available on that date. or something else happened");
            }
        } catch (Exception e) {
            System.out.println("Invalid date format. Please use yyyy-mm-dd.");
            scanner.nextLine();
        }
    }

    /**
     * Generates a bill for a given patient and displays it.
     */
    private static void generateBill() {
        try {
            System.out.print("Enter Patient ID to generate bill: ");
            int patientId = scanner.nextInt();
            scanner.nextLine();
            System.out.println("Bill date:(yyyy-mm-dd)");
            String dateInput = scanner.nextLine();
            LocalDate date = LocalDate.parse(dateInput);
            System.out.println("Enter the services, comma seperated");
            
            String servicesString = scanner.nextLine();
            String[] servicesList = servicesString.split(",");
            ArrayList<String> services = new ArrayList<>();
            for (String s: servicesList) {
            	services.add(s);
            }
            
           
            
            int billId = hospitalSystem.getNextBillId();
            Bill bill = new Bill(billId,patientId,date,services);
            bill.setAmount(services.size()*bill.getAmount());
            
            System.out.println("New Bill is generated.");
            hospitalSystem.generateBill(bill);		
            
            }
            
            

            
        
         catch (Exception e) {
            System.out.println("An error occurred while generating the bill: " + e.getMessage());
            scanner.nextLine(); // clear buffer
        }
    }


    /**
     * Displays available reports in the system.
     */
    private static void showReports() {
        System.out.println("Which report do you want to view?");
        String subMenu = "1. Patients\n2. Doctors\n3. Appointments\n4. Billing\n5. Departments\n6. All";
        System.out.println(subMenu);
        int option = scanner.nextInt();
        scanner.nextLine();

        switch (option) {
            case 1: hospitalSystem.generatePatientReport(); break;
            case 2: hospitalSystem.generateDoctorReport(); break;
            case 3: hospitalSystem.generateAppointmentReport(); break;
            case 4: hospitalSystem.generateBillingReport(); break;
            case 5: hospitalSystem.generateDepartmentReport(); break;
            case 6:
                hospitalSystem.generatePatientReport();
                System.out.println();
                hospitalSystem.generateDoctorReport();
                System.out.println();
                hospitalSystem.generateAppointmentReport();
                System.out.println();
                hospitalSystem.generateBillingReport();
                System.out.println();
                hospitalSystem.generateDepartmentReport();
                System.out.println();
                System.out.println("All reports displayed.");
                break;
            default:
                System.out.println("Invalid option.");
        }
    }

    /**
     * Displays all registered doctors.
     */
    private static void showAllDoctors() {
        System.out.println("Doctor ID\tDoctor Name\tSpecialization\tDepartment ID");
        int count = 0;
        for (Doctor doc : hospitalSystem.getDoctors()) {
            System.out.printf("%d\t%s\t%s\t%d\n", doc.getId(), doc.getName(), doc.getSpecialization(),
                    doc.getDepartment() != null ? doc.getDepartment().getDepartmentId() : -1);
            count++;
        }

        if (count > 0) {
            System.out.printf("There are %d registered doctors.\n", count);
        } else {
            System.out.println("There are no registered doctors.");
        }
    }

    /**
     * Displays all available departments.
     */
    private static void showAllDepartments() {
        System.out.println("Department ID\tDepartment Name");
        int count = 0;
        for (Department dep : hospitalSystem.getDepartments()) {
            System.out.printf("%d\t%s\n", dep.getDepartmentId(), dep.getDepartmentName());
            count++;
        }

        if (count > 0) {
            System.out.printf("There are %d departments.\n", count);
        } else {
            System.out.println("There are no available departments.");
        }
    }
}
