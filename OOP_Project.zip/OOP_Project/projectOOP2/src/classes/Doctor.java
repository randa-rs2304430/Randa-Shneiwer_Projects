package classes;

import java.io.Serializable;
import java.util.ArrayList;

/**
* Represents a doctor in the hospital system, extending the Person class.
* Each doctor has a specialization, a department, and a list of appointments.
* @author Randa, Khwla
*/
public class Doctor extends Person implements Serializable {
	/**
	 * Default serial Version Id
	 */
	private static final long serialVersionUID = 1L;
	private String specialization;
	private Department department;
	private ArrayList<Appointment> appointments = new ArrayList<>();

	/**
	 * Constructs a Doctor with the specified details.
	 *
	 * @param id             The unique ID of the doctor.
	 * @param name           The name of the doctor.
	 * @param contact        The contact information of the doctor.
	 * @param gender         The gender of the doctor.
	 * @param specialization The doctor's medical specialization.
	 */
	public Doctor(int id, String name, Contact contact, Gender gender, String specialization) {
		super(id, name, contact, gender);
		setSpecialization(specialization);
	}
	 public Doctor() {
	        // no-arg constructor required for deserialization
	    }
	/**
	 * Gets the doctor's specialization.
	 *
	 * @return The specialization of the doctor.
	 */
	public String getSpecialization() {
		return specialization;
	}

	/**
	 * Sets the doctor's specialization.
	 *
	 * @param specialization The specialization to set.
	 */
	public void setSpecialization(String specialization) {
		this.specialization = specialization;
	}

	/**
	 * Gets the department the doctor belongs to.
	 *
	 * @return The department of the doctor.
	 */
	public Department getDepartment() {
		return department;
	}

	/**
	 * Sets the department the doctor belongs to.
	 *
	 * @param department The department to assign.
	 */
	public void setDepartment(Department department) {
		this.department = department;
	}

	/**
	 * Gets the list of appointments associated with the doctor.
	 *
	 * @return A list of appointments.
	 */
	public ArrayList<Appointment> getAppointments() {
		return appointments;
	}

	/**
	 * Displays the doctor's details using the overridden toString method.
	 */
	@Override
	public void displayDetails() {
		System.out.println(toString());
	}

	/**
	 * Returns a string representation of the doctor's information.
	 *
	 * @return A string containing doctor details.
	 */
	@Override
	public String toString() {
		return  "Doctor ["+super.toString()+"specialization=" + specialization + ", department=" + department
				+ ", appointments=" + appointments + "]";
	}
}