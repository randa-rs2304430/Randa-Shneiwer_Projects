package classes;

/**
 * Represents a contract for any class that can calculate a payment (e.g., bills, services).
 */
public interface Payable {

    /**
     * Calculates the payment amount based on the given bill ID.
     *
     * @param billId the ID of the bill for which payment is to be calculated
     * @return the calculated payment amount
     */
    public double calculatePayment(int billId);
}
