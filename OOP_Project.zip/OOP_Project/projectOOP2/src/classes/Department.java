package classes;

import java.io.Serializable;
import java.util.ArrayList;

/**
 * Represents a hospital department that contains doctors and has a unique ID and name.
 * @author Randa , Wadha
 */
public class Department implements Serializable{
	/**
	 * Default serial Version Id
	 */
	private static final long serialVersionUID = 1L;
	private int departmentId;
	private String departmentName;
	private ArrayList<Doctor> doctorsInThisDepartment;

	/**
	 * Constructs a Department with a specified ID and name.
	 *
	 * @param departmentId   The unique ID of the department.
	 * @param departmentName The name of the department.
	 */
	public Department(int departmentId, String departmentName) {
		this.departmentId = departmentId;
		this.departmentName = departmentName;
		this.doctorsInThisDepartment = new ArrayList<>();
	}
	 public Department() {
	        // no-arg constructor required for deserialization
	    }

	/**
	 * Adds a doctor to the department.
	 *
	 * @param doctor The doctor to be added.
	 */
	public void addDoctor(Doctor doctor) {
		if (doctor != null) {
			doctorsInThisDepartment.add(doctor);
			System.out.println("Doctor added to department.");
		} else {
			System.out.println("Cannot add null doctor.");
		}
	}

	/**
	 * Removes a doctor from the department by their ID.
	 *
	 * @param doctorId The ID of the doctor to remove.
	 */
	public void removeDoctor(int doctorId) {
		Doctor toRemove = null;
		for (Doctor doctor : doctorsInThisDepartment) {
			if (doctor.getId() == doctorId) {
				toRemove = doctor;
				break;
			}
		}
		if (toRemove != null) {
			doctorsInThisDepartment.remove(toRemove);
			System.out.println("Doctor removed from department.");
		} else {
			System.out.println("Doctor with ID " + doctorId + " not found.");
		}
	}

	/**
	 * Gets the department ID.
	 *
	 * @return The department ID.
	 */
	public int getDepartmentId() {
		return departmentId;
	}

	/**
	 * Sets the department ID.
	 *
	 * @param departmentId The ID to set.
	 */
	public void setDepartmentId(int departmentId) {
		this.departmentId = departmentId;
	}

	/**
	 * Gets the department name.
	 *
	 * @return The department name.
	 */
	public String getDepartmentName() {
		return departmentName;
	}

	/**
	 * Sets the department name.
	 *
	 * @param departmentName The name to set.
	 */
	public void setDepartmentName(String departmentName) {
		this.departmentName = departmentName;
	}

	/**
	 * Gets the list of doctors in this department.
	 *
	 * @return List of doctors.
	 */
	public ArrayList<Doctor> getDoctorsInThisDepartment() {
		return doctorsInThisDepartment;
	}

	/**
	 * Sets the list of doctors in this department.
	 *
	 * @param doctorsInThisDepartment The list of doctors to set.
	 */
	public void setDoctorsInThisDepartment(ArrayList<Doctor> doctorsInThisDepartment) {
		this.doctorsInThisDepartment = doctorsInThisDepartment;
	}

	/**
	 * Displays the details of the department including its doctors.
	 */
	public void displayDepartmentDetails() {
		System.out.println("Department ID: " + departmentId);
		System.out.println("Department Name: " + departmentName);
		System.out.println("Doctors in this Department:");
		if (doctorsInThisDepartment.isEmpty()) {
			System.out.println("No doctors assigned to this department.");
		} else {
			for (Doctor doctor : doctorsInThisDepartment) {
				doctor.displayDetails();
			}
		}
	}
}
